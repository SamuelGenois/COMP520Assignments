#!/bin/sh

# Use case: build.sh, use from root folder
cd src
make
make clean
