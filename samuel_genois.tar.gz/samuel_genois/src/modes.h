#define SCAN 0
#define TOKENS 1
#define PARSE 2

char mode;
