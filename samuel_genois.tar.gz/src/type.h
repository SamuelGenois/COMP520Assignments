#include "symbol.h"

void type(STMT *ast);