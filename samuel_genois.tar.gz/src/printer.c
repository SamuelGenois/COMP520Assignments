//Pretty printer
void pretty(STMT astRoot) {
    fprintf(stderr, "Error: Not Implemented\n");
	exit(1);
}

//Codegen
void genCode(STMT astRoot) {
    fprintf(stderr, "Error: Not Implemented\n");
	exit(1);
}