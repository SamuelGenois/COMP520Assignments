#define SCAN 0
#define TOKENS 1
#define PARSE 2
#define PRETTY 3
#define SYMBOLPRINT 4
#define TYPECHECK 5
#define CODEGEN 6

char mode;
