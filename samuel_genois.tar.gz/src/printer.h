#include "type.h"

//Pretty printer
void pretty(STMT *ast);

//Codegen
void codeGen(STMT *ast);