//Pretty printer
void pretty(STMT astRoot);

//Codegen
void genCode(STMT astRoot);